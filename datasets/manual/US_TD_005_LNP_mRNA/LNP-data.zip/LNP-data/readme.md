README – Analytical Ultracentrifugation (AUC) Dataset

General Information

Dataset Title: AUC Experimental data and edit profiles for manuscript:

High-resolution characterization of protein-conjugated, mRNA-loaded lipid nanoparticles by analytical ultracentrifugation
 

Authors: Sophia Bird1%, Connor Smith2%, Nahal Habibi2%, Samantha Rivera2, Saeed Mortezazadeh1, Reece Martin1, Benjamin M. Geilich2, Gilles Besin2, Borries Demeler1,3

% Sophia Bird, Connor Smith, and Nahal Habibi contributed equally to this study

Affiliations:
1. University of Lethbridge, Dept. of Chemistry and Biochemistry, Lethbridge, AB, T1K4M3, Canada
2. Orbital Therapeutics, Cambridge, MA, 02142, USA
3. University of Montana, Dept. of Chemistry and Biochemistry, Missoula, MT 59812, USA

Contact Information: demeler@gmail.com

Description

This dataset contains analytical ultracentrifugation (AUC) measurements of lipid nanoparticle and accompanes the above cited manuscript.


Contents

Experimental data from the Optima AUC stored in OpenAUC format (Cölfen H, Laue TM, Wohlleben W, Schilling K, Karabudak E, Langhorst BW, Brookes E, Dubbs B, Zollars D, Rocco M, Demeler B. The Open AUC Project. Eur Biophys J. 2010 Feb;39(3):347-59. doi: 10.1007/s00249-009-0438-9. Epub 2009 Mar 19. PMID: 19296095; PMCID: PMC2812709.) for four experiments containing data from the original density matching experiments (4 D2O/H2O ratios, Fluorescence data for protein-conjugated LNPs, and UV controls for labeled and unlabeled proteins. Data can be imported into UltraScan, and the included edit profiles can be copied to the ~/ultrascan/results/RunID folder to recreate the original edited datasets. All other pertinent data such as buffer details, centerpiece, instrument type, analysis approach, when not available inside the openAUC formatted data, can be obtained from the original manuscript.

Software used: UltraScan Release 7875

File Formats:
Raw files: openAUC format (UltraScan)

License

This dataset is made available under the CC-BY 4.0 license.

Citation

If you use this dataset, please cite:

Authors: Sophia Bird1, Connor Smith2, Nahal Habibi2, Samantha Rivera2, Saeed Mortezazadeh1, Reece Martin1, Benjamin M. Geilich2, Gilles Besin2, Borries Demeler1,3
High-resolution characterization of protein-conjugated, mRNA-loaded lipid nanoparticles by analytical ultracentrifugation
Published in: Advanced Functional Materials

